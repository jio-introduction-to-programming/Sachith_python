class Vehicle:
    '''
        Task 1: Create a class Vehicle with the attributes: name, speed, and mileage.
        Implement the methods: __init__, a method to change the speed, and a method to get speed.
    '''
    def __init__(self, name, speed, mileage):
        pass

    def change_speed(self, new_speed):
        pass

    def get_speed(self):
        pass


class Animal:
    '''
        Task 2: Create a class Animal with the attributes: name, age, and type.
        Implement the methods: __init__, a method to change the age, and a method to get age.
    '''
    def __init__(self, name, age, type):
        pass

    def change_age(self, new_age):
        pass

    def get_age(self):
        pass


class Plant:
    '''
        Task 3: Create a class Plant with the attributes: name, height and type.
        Implement the methods: __init__, a method to change the height, and a method to get height.
    '''
    def __init__(self, name, height, type):
        pass

    def change_height(self, new_height):
        pass

    def get_height(self):
        pass


class Tree(Plant):
    '''
        Task 4: Create a class Tree which inherits from the Plant class.
        Add a new attribute: age. Also add a new method to change the age, and a method to get age.
    '''
    def __init__(self, name, height, type, age):
        pass

    def change_age(self, new_age):
        pass

    def get_age(self):
        pass
